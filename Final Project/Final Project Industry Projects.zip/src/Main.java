import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import java.util.Date;

/**
 * @author luisperez
 * @version 1.0
 * @date 06/11/2024
 */
public class Main extends Application {

    public void start(Stage primaryStage) {
        TableView<Task> tableView = new TableView<>();
        ObservableList<Task> data = FXCollections.observableArrayList();
        tableView.setItems(data);

        TableColumn<Task, String> notesColumn = new TableColumn<>("Note");
        notesColumn.setMinWidth(300);
        notesColumn.setCellValueFactory(
                new PropertyValueFactory<>("notes"));

        TableColumn<Task, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setMinWidth(200);
        dateColumn.setCellValueFactory(
                new PropertyValueFactory<>("date"));

        tableView.getColumns().addAll(notesColumn, dateColumn);

        FlowPane flowPane = new FlowPane(3, 3);
        TextField tfNotes = new TextField();
        Button btAddNote = new Button("Add new note");
        Button btDeleteRow = new Button("Delete note");
        tfNotes.setPrefColumnCount(5);

        flowPane.getChildren().addAll(new Label("Notes: "),
                tfNotes, new Label("Date"),
                btAddNote, btDeleteRow);

        btAddNote.setOnAction(e -> {
            Date date = new Date();
            data.add(new Task(date, tfNotes.getText()));
            tfNotes.clear();
        });

        btDeleteRow.setOnAction(e -> {
            data.remove(tableView.getSelectionModel().getSelectedItem());
        });

        BorderPane pane = new BorderPane();
        pane.setCenter(tableView);
        pane.setBottom(flowPane);

        Scene scene = new Scene(pane, 500, 250);
        primaryStage.setTitle("Notes");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
