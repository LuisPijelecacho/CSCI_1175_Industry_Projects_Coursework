import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import static javafx.application.Application.launch;
//import java.awt.*;

public class Main extends Application {
    public void start(Stage stage) {


        BorderPane borderPane = new BorderPane();
        GridPane gridPane = new GridPane();

        MenuBar menuBar = new MenuBar();
        Menu operationsMenu = new Menu("Operations");
        MenuItem calculateMenuItem = new MenuItem("Calculate");
        MenuItem exitMenuItem = new MenuItem("Exit");
        operationsMenu.getItems().add(calculateMenuItem);
        operationsMenu.getItems().add(exitMenuItem);

        menuBar.getMenus().add(operationsMenu);

        borderPane.setTop(menuBar);

        TextField investmentAmountTextField = new TextField();
        TextField numberOfYearsTextField = new TextField();
        TextField annualInterestRateTextField = new TextField();
        TextField futureValueTextField = new TextField();
        Button calculateButton = new Button("Calculate");

        calculateButton.setOnAction( e -> {
            try {
                double monthlyInterestRate = Double.parseDouble(annualInterestRateTextField.getText()) / 12 / 100;
                double numberOfYears = Double.parseDouble(numberOfYearsTextField.getText());
                double investmentAmount = Double.parseDouble(investmentAmountTextField.getText());

                double futureValue = investmentAmount * Math.pow(1 + monthlyInterestRate, numberOfYears * 12);

                futureValueTextField.setEditable(false);
                futureValueTextField.setText(String.format("%.2f", futureValue));
            }catch (NumberFormatException e1) {
                futureValueTextField.setText("Invalid Input");
            }

        });
        calculateMenuItem.setOnAction(e -> {
            try {
                double monthlyInterestRate = Double.parseDouble(annualInterestRateTextField.getText()) / 12 / 100;
                double numberOfYears = Double.parseDouble(numberOfYearsTextField.getText());
                double investmentAmount = Double.parseDouble(investmentAmountTextField.getText());

                double futureValue = investmentAmount * Math.pow(1 + monthlyInterestRate, numberOfYears * 12);

                futureValueTextField.setEditable(false);
                futureValueTextField.setText(String.format("%.2f", futureValue));
            }catch (NumberFormatException e1) {
                futureValueTextField.setText("Invalid Input");
            }

        });

        exitMenuItem.setOnAction( e -> {
            System.exit(0);
        });


        gridPane.add(new Label("Investment Amount"), 0, 0);
        gridPane.add(investmentAmountTextField, 1, 0);
        gridPane.add(new Label("Number of Years"), 0, 1);
        gridPane.add(numberOfYearsTextField, 1, 1);
        gridPane.add(new Label("Annual Interest Rate"), 0, 2);
        gridPane.add(annualInterestRateTextField, 1, 2);
        gridPane.add(new Label("Future Value"), 0, 3);
        gridPane.add(futureValueTextField, 1, 3);
        gridPane.add(calculateButton, 1, 4);



        VBox holder = new VBox();
        holder.getChildren().addAll(borderPane, gridPane);


        Scene scene = new Scene(holder, 800, 600);

        stage.setScene(scene);
        stage.setTitle("Investment Calculator");
        stage.show();




    }
    public static void main(String[] args) {
        launch(args);
    }

}
