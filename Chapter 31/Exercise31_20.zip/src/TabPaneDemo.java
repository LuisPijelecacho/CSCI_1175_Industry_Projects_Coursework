import javafx.application.Application;
import javafx.geometry.Side;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class TabPaneDemo extends Application {
    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        TabPane tabPane = new TabPane();
        Tab tab1 = new Tab("Line");
        StackPane pane1 = new StackPane();
        pane1.getChildren().add(new Line(10, 10, 80, 80));
        tab1.setContent(pane1);
        Tab tab2 = new Tab("Rectangle");
        tab2.setContent(new Rectangle(10, 10, 200, 200));
        Tab tab3 = new Tab("Circle");
        tab3.setContent(new Circle(50, 50, 20));
        Tab tab4 = new Tab("Ellipse");
        tab4.setContent(new Ellipse(10, 10, 100, 80));
        tabPane.getTabs().addAll(tab1, tab2, tab3, tab4);

        BorderPane borderPane = new BorderPane();
        HBox hbox = new HBox();

        RadioButton topRadio = new RadioButton("Top");
        RadioButton leftRadio = new RadioButton("Left");
        RadioButton rightRadio = new RadioButton("Right");
        RadioButton bottomRadio = new RadioButton("Bottom");

        ToggleGroup toggleGroup = new ToggleGroup();
        topRadio.setToggleGroup(toggleGroup);
        leftRadio.setToggleGroup(toggleGroup);
        rightRadio.setToggleGroup(toggleGroup);
        bottomRadio.setToggleGroup(toggleGroup);
        hbox.getChildren().addAll(topRadio, leftRadio, rightRadio, bottomRadio);



        borderPane.setTop(tabPane);
        borderPane.setBottom(hbox);
        borderPane.setCenter(pane1);


        topRadio.setOnAction(e -> {
            if (topRadio.isSelected()) {
                tabPane.setSide(Side.TOP);


            }
        });

        leftRadio.setOnAction(e -> {
            if (leftRadio.isSelected()) {

                tabPane.setSide(Side.LEFT);

            }
        });

        rightRadio.setOnAction(e -> {
            if (rightRadio.isSelected()) {

                tabPane.setSide(Side.RIGHT);

            }
        });

        bottomRadio.setOnAction(e -> {
            if (bottomRadio.isSelected()) {
                tabPane.setSide(Side.BOTTOM);

            }
        });



        Scene scene = new Scene(borderPane, 300, 250);
        primaryStage.setTitle("DisplayFigure");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     * line.
     */
    public static void main(String[] args) {
        launch(args);
    }
}
