import javafx.application.Application;
import static javafx.application.Application.launch;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Exercise33_09Client extends Application {
    private final TextArea taServer = new TextArea();
    private final TextArea taClient = new TextArea();

    @Override
    public void start(Stage primaryStage) {
        taServer.setWrapText(true);
        taClient.setWrapText(true);

        BorderPane pane1 = new BorderPane();
        pane1.setTop(new Label("History"));
        pane1.setCenter(new ScrollPane(taServer));
        BorderPane pane2 = new BorderPane();
        pane2.setTop(new Label("New Message"));
        pane2.setCenter(new ScrollPane(taClient));

        VBox vBox = new VBox(5);
        vBox.getChildren().addAll(pane1, pane2);

        Scene scene = new Scene(vBox, 200, 200);
        primaryStage.setTitle("Exercise31_09Client");
        primaryStage.setScene(scene);
        primaryStage.show();

        ButtonListener buttonListener = new ButtonListener();
        taClient.setOnKeyPressed(keyEvent -> {
            if (keyEvent.getCode().equals(KeyCode.ENTER)) {
                keyEvent.consume();
                ActionEvent actionEvent = new ActionEvent();
                buttonListener.handle(actionEvent);
            }
        });
    }

    public static void main(String[] args) {
        launch(args);
    }

    private class ButtonListener implements EventHandler<ActionEvent> {
        public String host = "localhost";

        @Override
        public void handle(ActionEvent e) {
            new Thread(() -> {
                try (Socket socket = new Socket(host, 8000);
                     ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                     ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

                    String messageSent = taClient.getText().trim();
                    out.writeObject(messageSent);
                    out.flush();  // Ensure the message is sent immediately

                    String messageReceived = (String) in.readObject();

                    Platform.runLater(() -> {
                        taServer.appendText("Client: " + messageSent + "\n");
                        taServer.appendText("Server: " + messageReceived + "\n");
                        taClient.clear();  // Clear the input area after sending the message
                    });

                } catch (IOException | ClassNotFoundException ex) {
                    Platform.runLater(() -> {
                        taServer.appendText("Error: " + ex.getMessage() + "\n");
                    });
                }
            }).start();
        }
    }
}
