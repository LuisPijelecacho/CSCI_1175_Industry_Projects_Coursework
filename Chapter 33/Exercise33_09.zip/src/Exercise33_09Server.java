import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Exercise33_09Server extends Application {
    private final TextArea taServer = new TextArea();
    private final TextArea taClient = new TextArea();
    public Socket socketDummy = new Socket();

    @Override
    public void start(Stage primaryStage) {
        taServer.setWrapText(true);
        taClient.setWrapText(true);

        BorderPane pane1 = new BorderPane();
        pane1.setTop(new Label("History"));
        pane1.setCenter(new ScrollPane(taServer));
        BorderPane pane2 = new BorderPane();
        pane2.setTop(new Label("Client"));
        pane2.setCenter(new ScrollPane(taClient));

        VBox vBox = new VBox(5);
        vBox.getChildren().addAll(pane1, pane2);

        Scene scene = new Scene(vBox, 200, 200);
        primaryStage.setTitle("Exercise33_09Server");
        primaryStage.setScene(scene);
        primaryStage.show();





        new Thread(() -> {
            try (ServerSocket serverSocket = new ServerSocket(8000)) {
                //clientHandler.run();
                while (true) {
                    socketDummy = serverSocket.accept();
                    ClientHandler clientHandler = new ClientHandler(socketDummy);
                    new Thread(clientHandler).start();
                    taClient.setOnKeyPressed( e -> {
                        if (e.getCode().equals(KeyCode.ENTER)) {
                            //ClientHandler clientHandler2 = new ClientHandler(socketDummy);
                            clientHandler.run();
                        }
                    });
                }
            } catch (IOException e) {
                Platform.runLater(() -> taServer.appendText("Error: " + e.getMessage() + "\n"));
            }
        }).start();


    }


    private class ClientHandler implements Runnable {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
                 ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream())) {

                String messageReceived = (String) in.readObject();
                Platform.runLater(() -> taServer.appendText("Client: " + messageReceived + "\n"));

                String messageSent = taServer.getText().trim();
                out.writeObject(messageSent);
                Platform.runLater(() -> taServer.appendText("Server: " + messageSent + "\n"));

            } catch (IOException | ClassNotFoundException e) {
                Platform.runLater(() -> taServer.appendText("Error: " + e.getMessage() + "\n"));
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
