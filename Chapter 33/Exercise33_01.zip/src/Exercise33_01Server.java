import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import javax.swing.plaf.PanelUI;

public class Exercise33_01Server extends Application {
    private TextArea ta = new TextArea();

    @Override
    public void start(Stage primaryStage) {
        ta.setWrapText(true);
        Scene scene = new Scene(new ScrollPane(ta), 400, 200);
        primaryStage.setTitle("Exercise33_01Server");
        primaryStage.setScene(scene);
        primaryStage.show();

        new Thread(() -> {
            try (ServerSocket serverSocket = new ServerSocket(8000)) {
                Platform.runLater(() -> ta.appendText("Server started!\n"));

                while (true) {
                    Socket socket = serverSocket.accept();
                    new Thread(new ClientHandler(socket)).start();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private class ClientHandler implements Runnable {
        private Socket socket;

        public ClientHandler(Socket socket) {
            this.socket = socket;
        }

        @Override
        public void run() {
            try (ObjectInputStream inputFromClient = new ObjectInputStream(socket.getInputStream());
                 ObjectOutputStream outputToClient = new ObjectOutputStream(socket.getOutputStream())) {

                double annualInterestRate = inputFromClient.readDouble();
                int numOfYears = inputFromClient.readInt();
                double loanAmount = inputFromClient.readDouble();

                Loan loan = new Loan();
                loan.setAnnualInterestRate(annualInterestRate);
                loan.setNumberOfYears(numOfYears);
                loan.setLoanAmount(loanAmount);

                double monthlyPayment = loan.getMonthlyPayment();
                double totalPayment = loan.getTotalPayment();

                Platform.runLater(() -> {
                    ta.appendText("Annual Interest Rate: " + loan.getAnnualInterestRate() + "\n");
                    ta.appendText("Number Of Years: " + loan.getNumberOfYears() + "\n");
                    ta.appendText("Loan Amount: " + loan.getLoanAmount() + "\n");
                    ta.appendText("Monthly Payment: " + loan.getMonthlyPayment() + "\n");
                    ta.appendText("Total Payment: " + loan.getTotalPayment() + "\n");
                });

                outputToClient.writeDouble(monthlyPayment);
                outputToClient.writeDouble(totalPayment);
                outputToClient.flush();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
