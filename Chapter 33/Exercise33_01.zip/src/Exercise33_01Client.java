import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Exercise33_01Client extends Application {
    private TextField tfAnnualInterestRate = new TextField();
    private TextField tfNumOfYears = new TextField();
    private TextField tfLoanAmount = new TextField();
    private Button btSubmit = new Button("Submit");
    private TextArea ta = new TextArea();
    private String host = "localhost";

    @Override
    public void start(Stage primaryStage) {
        ta.setWrapText(true);

        GridPane gridPane = new GridPane();
        gridPane.add(new Label("Annual Interest Rate"), 0, 0);
        gridPane.add(tfAnnualInterestRate, 1, 0);
        gridPane.add(new Label("Number Of Years"), 0, 1);
        gridPane.add(tfNumOfYears, 1, 1);
        gridPane.add(new Label("Loan Amount"), 0, 2);
        gridPane.add(tfLoanAmount, 1, 2);
        gridPane.add(btSubmit, 2, 1);

        btSubmit.setOnAction(new ButtonListener());

        tfAnnualInterestRate.setAlignment(Pos.BASELINE_RIGHT);
        tfNumOfYears.setAlignment(Pos.BASELINE_RIGHT);
        tfLoanAmount.setAlignment(Pos.BASELINE_RIGHT);

        BorderPane pane = new BorderPane();
        pane.setCenter(new ScrollPane(ta));
        pane.setTop(gridPane);

        Scene scene = new Scene(pane, 400, 250);
        primaryStage.setTitle("Exercise33_01Client");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private class ButtonListener implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent actionEvent) {
            try (Socket socket = new Socket(host, 8000);
                 ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream())) {
                ObjectInputStream in = new ObjectInputStream(socket.getInputStream());

                double annualInterestRate = Double.parseDouble(tfAnnualInterestRate.getText());
                int numOfYears = Integer.parseInt(tfNumOfYears.getText());
                double loanAmount = Double.parseDouble(tfLoanAmount.getText());

                out.writeDouble(loanAmount);
                out.writeInt(numOfYears);
                out.writeDouble(annualInterestRate);

                out.flush();

                double monthlyPayment = in.readDouble();
                double totalPayment = in.readDouble();

                ta.appendText("Loan object sent to server: " + new Loan(annualInterestRate, numOfYears, loanAmount) + "\n");
                ta.appendText("Annual Interest Rate: " + annualInterestRate + "\n");
                ta.appendText("Number Of Years: " + numOfYears + "\n");
                ta.appendText("Loan Amount: " + loanAmount + "\n");
                ta.appendText("Monthly Payment : " + monthlyPayment + "\n");
                ta.appendText("Total Payment : " + totalPayment + "\n");

            } catch (IOException ex) {
                ta.appendText("Client exception: " + ex.getMessage() + "\n");
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
